package tech.ada.rflima.b3testesexercicios.repository;

import org.junit.jupiter.api.Test;

//Qual anotação devemos usar para subir o contexto do spring relacionado a persistência de dados?
public class UsuarioRepositoryTest {


    @Test
    void deveSalvarUsuarioComSucesso() {

    }


    @Test
    void deveListarTodosOsUsuarios() {

    }

    @Test
    void deveEncontrarUsuarioPorCpf() {

    }

    @Test
    void deveAtualizarUsuario() {

    }


    @Test
    void deveDeletarUsuario() {

    }


}
