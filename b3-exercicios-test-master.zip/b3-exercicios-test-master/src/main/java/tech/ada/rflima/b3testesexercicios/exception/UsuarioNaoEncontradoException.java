package tech.ada.rflima.b3testesexercicios.exception;

public class UsuarioNaoEncontradoException extends RuntimeException {

    public UsuarioNaoEncontradoException(String msg) {
        super(msg);
    }
}
