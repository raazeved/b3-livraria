package tech.ada.rflima.b3testesexercicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B3TestesExerciciosApplication {

    public static void main(String[] args) {
        SpringApplication.run(B3TestesExerciciosApplication.class, args);
    }

}
