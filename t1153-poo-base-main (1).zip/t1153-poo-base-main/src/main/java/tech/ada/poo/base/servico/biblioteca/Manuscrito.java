package tech.ada.poo.base.servico.biblioteca;

public class Manuscrito extends ItemCatalogo {
}
