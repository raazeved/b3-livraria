package tech.ada.poo.base.servico.compactar;

import tech.ada.poo.base.servico.compactar.elementos.Fluxo;

public interface InterfaceServicoStream {

    void compactar(Fluxo fluxo); // intervalo de dados

}
