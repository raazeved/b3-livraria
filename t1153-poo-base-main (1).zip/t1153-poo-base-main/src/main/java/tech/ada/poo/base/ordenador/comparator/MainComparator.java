package tech.ada.poo.base.ordenador.comparator;

import java.util.Collections;
import java.util.Comparator;

public class MainComparator {

    public static void main(String[] args) {

        Integer[] numeros = new Integer[5];
        numeros[0] = 12;
        numeros[1] = 2;
        numeros[2] = 33;
        numeros[3] = 81;
        numeros[4] = 21;

        // continuar daqui .. passando de array para lista
        // após revisar e praticar o conceito de interface
//        Collections.sort(numeros,
//            new Comparator<Integer>() {
//                @Override
//                public int compare(Integer o1, Integer o2) {
//                    return 0;
//                }
//            });
//
    }

}
