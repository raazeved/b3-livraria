package tech.ada.poo.base.servico.biblioteca;

import java.beans.beancontext.BeanContextServiceProviderBeanInfo;

public interface BibliotecaServiceVirtual extends BibliotecaService {


}
