package tech.ada.poo.base.servico.biblioteca;

public class Revista extends ItemCatalogo {
}
