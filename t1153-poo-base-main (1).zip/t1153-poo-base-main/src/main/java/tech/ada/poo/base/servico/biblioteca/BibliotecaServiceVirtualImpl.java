package tech.ada.poo.base.servico.biblioteca;

public class BibliotecaServiceVirtualImpl
    extends BibliotecaServiceImpl
        implements BibliotecaServiceVirtual {

    @Override
    public void reservar() {

    }

    @Override
    public boolean consultar(String titulos) {
        return false;
    }

}
