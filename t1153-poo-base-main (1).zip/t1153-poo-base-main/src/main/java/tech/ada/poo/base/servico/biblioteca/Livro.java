package tech.ada.poo.base.servico.biblioteca;

public class Livro extends ItemCatalogo {

    public Livro (String titulo) {
        super.setTitulo(titulo);
    }

}
