package tech.ada.poo.base.servico.biblioteca;

public interface BibliotecaService {

    void reservar();
    boolean consultar(String titulo);

}
