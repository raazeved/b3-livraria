package tech.ada.rflima.rpgassistant.model;

public class SlipDTO {

    private String advice;

    public String getAdvice() {
        return advice;
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }
}
