package tech.ada.rflima.rpgassistant.exception;

public class CampanhaNaoEncontradaException extends RuntimeException {

    public CampanhaNaoEncontradaException(String mensagem) {
        super(mensagem);
    }
}
