package tech.ada.rflima.rpgassistant.exception;

public class ChatException extends RuntimeException {

    public ChatException(String msg) {
        super(msg);
    }
}
