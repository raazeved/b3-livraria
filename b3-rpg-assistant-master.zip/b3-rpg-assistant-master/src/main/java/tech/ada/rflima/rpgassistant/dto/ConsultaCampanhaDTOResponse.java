package tech.ada.rflima.rpgassistant.dto;

public class ConsultaCampanhaDTOResponse {

    private Long id;
    private String nomeCampanha;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeCampanha() {
        return nomeCampanha;
    }

    public void setNomeCampanha(String nomeCampanha) {
        this.nomeCampanha = nomeCampanha;
    }
}
