import java.util.Collections;

public class Comparator {
    public static void main(String[] args){
        //Programação Orientada a Objetos II - Aula 1
        Integer[] numeros = new Integer[5];
        numeros[0] = 12;
        numeros[1] = 2;
        numeros[2] = 33;
        numeros[3] = 81;
        numeros[4] = 21;

    }
}
