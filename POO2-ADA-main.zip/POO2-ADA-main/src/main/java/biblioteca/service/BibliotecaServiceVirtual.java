package biblioteca.service;

public interface BibliotecaServiceVirtual extends BibliotecaService{
}
