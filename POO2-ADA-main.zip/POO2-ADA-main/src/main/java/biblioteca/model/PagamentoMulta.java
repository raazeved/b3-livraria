package biblioteca.model;

public class PagamentoMulta extends Operacoes{
    @Override
    public void setVirtual(boolean virtual) {
        super.setVirtual(false);
    }
}
