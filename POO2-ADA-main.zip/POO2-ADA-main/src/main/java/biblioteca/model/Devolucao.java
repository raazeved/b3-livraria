package biblioteca.model;

public class Devolucao extends Operacoes{
    @Override
    public void setVirtual(boolean virtual) {
        super.setVirtual(false);
    }
}
