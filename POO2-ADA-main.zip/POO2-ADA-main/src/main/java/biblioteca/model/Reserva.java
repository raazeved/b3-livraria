package biblioteca.model;

public class Reserva extends Operacoes{
}
