package tech.ada.ClearingBET;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClearingBetApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClearingBetApplication.class, args);
	}

}
