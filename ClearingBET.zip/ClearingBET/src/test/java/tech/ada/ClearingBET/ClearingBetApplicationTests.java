package tech.ada.ClearingBET;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClearingBetApplicationTests {

	@Test
	void contextLoads() {
	}

}
