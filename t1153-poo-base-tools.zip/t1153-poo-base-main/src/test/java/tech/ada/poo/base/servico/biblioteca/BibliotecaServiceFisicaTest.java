package tech.ada.poo.base.servico.biblioteca;

import org.junit.jupiter.api.Test;

public class BibliotecaServiceFisicaTest {

    @Test public void cadastrar() {
        System.out.println("sucess");
    }

}
