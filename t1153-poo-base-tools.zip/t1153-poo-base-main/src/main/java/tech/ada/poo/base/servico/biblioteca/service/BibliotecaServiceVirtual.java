package tech.ada.poo.base.servico.biblioteca.service;

public interface BibliotecaServiceVirtual extends BibliotecaService {

    // incrementos metodos adicionais
    // compartilharPorEmail
    // baixarItem
    // verificarDisponibilidadeOnline
    // adicionarAosFavoritos
    // obterPrevia
    // avaliarItem

}
