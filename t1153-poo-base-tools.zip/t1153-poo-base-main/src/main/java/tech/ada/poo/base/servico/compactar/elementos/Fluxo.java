package tech.ada.poo.base.servico.compactar.elementos;

public class Fluxo {
}
