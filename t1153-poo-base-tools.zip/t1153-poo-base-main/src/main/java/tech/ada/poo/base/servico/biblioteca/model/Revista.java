package tech.ada.poo.base.servico.biblioteca.model;

public class Revista extends ItemCatalogo {
}
