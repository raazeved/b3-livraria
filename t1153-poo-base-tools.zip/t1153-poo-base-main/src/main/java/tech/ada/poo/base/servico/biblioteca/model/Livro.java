package tech.ada.poo.base.servico.biblioteca.model;

public class Livro extends ItemCatalogo {

    public Livro (String titulo) {
        super.setTitulo(titulo);
    }

}
